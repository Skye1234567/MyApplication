package com.example.myapplication.Business_Logic;

import java.security.SecureRandom;
import java.util.Random;
// leon walras



public class Accountant {

    private Random generator;

    public Accountant() {
        this.generator = new Random();

    }


}
