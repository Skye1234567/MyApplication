package com.example.myapplication.Business_Logic;


import java.util.*;


public class Manager_Logic {




    public ArrayList<Integer> shuffle_players(Integer num_players){
        ArrayList a = new ArrayList();
        Integer i;
        for ( i =0;i<num_players;i++){a.add(i);}
        //shuffle




        return a;



    };
}
